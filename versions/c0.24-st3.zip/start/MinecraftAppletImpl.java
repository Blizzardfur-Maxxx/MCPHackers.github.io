import java.net.URL;

import com.mojang.minecraft.MinecraftGameApplet;

public class MinecraftAppletImpl extends MinecraftGameApplet
{	
	public MinecraftAppletImpl()
	{
	}
	
	public URL getDocumentBase() {
		URL url;
		try {
			url = new URL("http://www.minecraft.net/game/");
		} catch (Exception  ex) {
			url = null;
			ex.printStackTrace();
		}
		return url;
	}
	
	public URL getCodeBase() {
		URL url;
		try {
			url = new URL("http://www.minecraft.net/game/");
		} catch (Exception  ex) {
			url = null;
			ex.printStackTrace();
		}
		return url;
	}
}