import org.lwjgl.LWJGLException;

import com.mojang.spacegame.SpaceGame;

public class Start
{
	public static void main(String[] args) throws LWJGLException {
		SpaceGame.main(args);
	}
}