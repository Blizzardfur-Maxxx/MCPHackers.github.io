import org.lwjgl.LWJGLException;

import com.mojang.ld22.Game;

public class Start
{
	public static void main(String[] args) throws LWJGLException {
		Game.main(args);
	}

}