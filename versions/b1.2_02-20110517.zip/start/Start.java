import net.minecraft.client.Minecraft;
import java.io.File;
import java.lang.reflect.Field;

import org.lwjgl.LWJGLException;

public class Start
{

  public static void main(String[] args) throws LWJGLException
  {
      try
      {
          Field f = Minecraft.class.getDeclaredField("workingDirectory");
          Field.setAccessible(new Field[] { f }, true);
      }
      catch (Exception e)
      {
          e.printStackTrace();
          return;
      }
      Minecraft.main(args);
   }

}
