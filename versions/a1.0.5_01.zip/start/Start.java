import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Frame;
import java.io.File;
import java.lang.reflect.Field;

import net.minecraft.client.MinecraftApplet;
import net.minecraft.src.Minecraft;
import net.minecraft.src.Session;

public class Start
{
	public static void startMainThread(String username, String sessionId) {
		startMainThread(username, sessionId, null);
	}

	public static void startMainThread(String username, String sessionId, String server) {
		boolean fullscreen = false;
		int width = 854;
		int height = 480;
		Frame frame = new Frame("Minecraft");
		Canvas canvas = new Canvas();
		frame.setLayout(new BorderLayout());
		frame.add(canvas, "Center");
		canvas.setPreferredSize(new Dimension(width, height));
		frame.pack();
		frame.setLocationRelativeTo(null);
		Minecraft mc = new MinecraftImpl(frame, canvas, null, width, height, fullscreen, frame);
		Thread mcThread = new Thread(mc, "Minecraft main thread");
		mcThread.setPriority(10);
		try
		{
			Field f = Minecraft.class.getDeclaredField("minecraftDir");
			Field.setAccessible(new Field[] { f }, true);
			f.set(null, new File("."));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return;
		}
		mc.appletMode = false;
		mc.minecraftUri = "www.minecraft.net";
		if(username != null && sessionId != null) {
			mc.session = new Session(username, sessionId);
		}
		else {
			mc.session = new Session("Player" + System.currentTimeMillis() % 1000L, "");
		}

		if(server != null) {
			String[] ipAndPort = server.split(":");
			mc.setServer(ipAndPort[0], Integer.parseInt(ipAndPort[1]));
		}

		frame.setVisible(true);
		frame.addWindowListener(new GameWindowListener(mc, mcThread));
		mcThread.start();
	}

	public static void main(String[] args) {
		String username = "Player" + System.currentTimeMillis() % 1000L;
		if(args.length > 0) {
			username = args[0];
		}

		String sessionId = "-";
		if(args.length > 1) {
			sessionId = args[1];
		}

		startMainThread(username, sessionId);
	}

}