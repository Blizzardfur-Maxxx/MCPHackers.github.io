import org.lwjgl.LWJGLException;

import com.mojang.chambered.Chambered;

public class Start
{
	public static void main(String[] args) throws LWJGLException {
		Chambered.main(args);
	}

}